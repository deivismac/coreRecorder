Core Recorder v0.5.0
====================


+--------------------------------------------------------------+
|                                                              |
|   ===> READ THIS FIRST OR THE APP WILL NOT RUN <===          |
|                                                              |
|   1. Extract the zip somewhere permanent (Documents,         |
|      Desktop, etc). Do NOT run from inside the zip.          |
|                                                              |
|   2. RIGHT-CLICK coreRecorder.exe -> Properties.             |
|                                                              |
|   3. At the BOTTOM of the General tab there is a checkbox    |
|      that says "Unblock" (next to a security warning).       |
|                                                              |
|   4. TICK "Unblock" -> click Apply -> click OK.              |
|                                                              |
|   5. NOW double-click coreRecorder.exe.                      |
|                                                              |
|   Without step 2-4, Windows may silently kill the exe with   |
|   no popup, no UAC prompt, no error. Nothing happens - you   |
|   double-click and Windows just blocks it in the background. |
|                                                              |
+--------------------------------------------------------------+


What is this?
-------------
Companion app for the Core Cinematics FiveM resource. Captures the GTA
window via ffmpeg and produces an .mp4 (with optional motion blur).
The editor talks to it on http://127.0.0.1:7861 - you do not open it
manually beyond the first launch.


What's new in v0.5.0
--------------------
- FIXED: the recorder could quietly record on your CPU even with a
  perfectly good NVIDIA / AMD / Intel GPU. ffmpeg renames its encoder
  settings between versions, and one renamed setting was enough to make
  the hardware check fail - so it fell back to CPU without telling you.
  The recorder now checks what your ffmpeg build actually supports
  before deciding, so that can't happen again.
- The status panel has an Encoder dropdown. It lists every encoder -
  NVIDIA NVENC, AMD AMF, Intel QuickSync, CPU - and the ones your PC
  can't use stay in the list, greyed out, with the reason when you hover
  ("no AMD GPU found", "NVIDIA driver is older than this ffmpeg build
  needs"). Pick one, or leave it on Auto and it takes the fastest
  available. Your choice is remembered.
- Refresh button next to it re-checks your hardware without restarting
  the recorder - handy after updating a GPU driver, or if you launched
  the recorder before the game.
- When you end up on CPU, the panel now says why in one line instead of
  leaving you guessing.
- First-boot ffmpeg download now grabs a stable release build instead of
  the nightly. The nightly needs a very recent GPU driver for hardware
  encoding and would silently drop some people to CPU recording.
- Diagnostics: running "coreRecorder.exe --probe-encoders" from a command
  prompt prints every encoder, whether it works on your PC, and what
  ffmpeg said if it doesn't. Send that output with a support ticket if
  recording is slower than you expect.

  NOTE for anyone who was already on CPU: if you have an older ffmpeg.exe
  sitting next to the recorder, delete it before launching v0.5.0. The
  recorder will re-download a build that works with your driver.


What's new in v0.4.0
--------------------
- The recorder now asks for administrator rights on launch (a normal
  Windows UAC prompt). THIS IS EXPECTED AND RECOMMENDED - it unlocks
  the same GPU-priority boost OBS gets when run as administrator, so
  recording stays smooth even while the game is using your whole PC.
  If you decline the prompt the recorder still works, just without the
  full boost. To stop it asking, set "auto_elevate": false in
  config.json.
- Recording consistency overhaul: high CPU priority, GPU scheduling
  priority, capture threads registered with the Windows multimedia
  scheduler, and the recorder is exempted from Windows 11 background
  power throttling. No more 40 fps -> 2 fps -> 30 fps sawtooth when
  the game has focus. Works identically on NVIDIA, AMD and Intel.
- Visibly cleaner output at the same resolution: the temporary capture
  file is now stored near-lossless before the final encode, so the
  finished .mp4 no longer carries double-compression softness. Temp
  files are a bit larger during processing; they are deleted after.
- New "4K Upscale" toggle in the editor's Export panel (only shown when
  your game runs below 4K, off by default). Renders the final video at
  4K from your native resolution - crisper result, and platforms like
  YouTube/Discord give 4K uploads a much better quality budget. Costs
  a bigger file and a slower processing step. Requires the matching
  Core Cinematics resource update.
- Windowed capture uses Windows.Graphics.Capture (the OBS "Window
  Capture" mode) again - the frame-drop bug that forced v0.3.0 onto
  the CPU path is fixed. Fullscreen still uses GPU desktop duplication,
  and the recorder falls back automatically if either is unavailable.
- The status panel shows a "Priority" row (Boosted (admin) / Standard)
  so you can confirm at a glance the boost is active.


Quick start (after you have done the Unblock above)
---------------------------------------------------
1. Double-click coreRecorder.exe and accept the administrator prompt.
   First boot: a loading screen appears and the recorder auto-downloads
   ffmpeg.exe (~78 MB) next to itself. The progress bar shows the
   download in real time. Subsequent boots are instant.

2. Leave the status panel open while you record. The editor's Export
   button talks to it over localhost - no manual interaction needed.

3. Finished clips land in:
     %USERPROFILE%\Videos\Core Cinematics\

If first boot fails (no internet, firewall, etc.) the panel shows
"Setup failed" + a Retry button. You can also drop your own ffmpeg.exe
next to coreRecorder.exe to skip the auto-download entirely.


Still does not run? (rare, after Unblock is done)
-------------------------------------------------
Windows Defender may have quarantined it silently. Check:

   Settings -> Privacy & security -> Windows Security
       -> Virus & threat protection -> Protection history

If coreRecorder.exe is listed there, click it and choose "Allow on
device". The exe is unsigned, so heuristics sometimes flag it; this
restores it permanently.

If Smart App Control is set to "On" (Windows 11), it will block any
unsigned exe with no UI. Settings -> Privacy & security -> Windows
Security -> App & browser control -> Smart App Control. Set it to
"Evaluation" or "Off". Note: this is one-way on Windows 11 - once
turned off, you cannot turn it back on without reinstalling Windows.


First-run popup warnings (the normal ones)
------------------------------------------
After Unblock, Windows may still show:
- "Windows protected your PC" (blue popup) -> click "More info" ->
  "Run anyway".
- Browser download warning ("isn't commonly downloaded") -> Keep.

Both are normal for unsigned exes from a small dev. They're separate
from the silent-block issue and can be clicked through.


Verify the download
-------------------
SHA-256 of coreRecorder.exe is in SHA256SUMS.txt next to this file.
Verify with PowerShell:
   Get-FileHash coreRecorder.exe -Algorithm SHA256


Logs
----
Daily-rotated under <recorder folder>\logs\recorder.log.YYYY-MM-DD.
Useful when reporting issues - paste the last few lines.
