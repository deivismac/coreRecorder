Core Recorder v0.3.0
====================


+--------------------------------------------------------------+
|                                                              |
|   ===> READ THIS FIRST OR THE APP WILL NOT RUN <===          |
|                                                              |
|   1. Extract the zip somewhere permanent (Documents,         |
|      Desktop, etc). Do NOT run from inside the zip.          |
|                                                              |
|   2. RIGHT-CLICK coreRecorder.exe -> Properties.             |
|                                                              |
|   3. At the BOTTOM of the General tab there is a checkbox    |
|      that says "Unblock" (next to a security warning).       |
|                                                              |
|   4. TICK "Unblock" -> click Apply -> click OK.              |
|                                                              |
|   5. NOW double-click coreRecorder.exe.                      |
|                                                              |
|   Without step 2-4, Windows may silently kill the exe with   |
|   no popup, no UAC prompt, no error. Nothing happens — you   |
|   double-click and Windows just blocks it in the background. |
|                                                              |
+--------------------------------------------------------------+


What is this?
-------------
Companion app for the Core Cinematics FiveM resource. Captures the GTA
window via ffmpeg and produces an .mp4 (with optional motion blur).
The editor talks to it on http://127.0.0.1:7861 — you do not open it
manually beyond the first launch.


What's new in v0.3.0
--------------------
- Capture backend is now picked automatically based on how the game is
  running:
    * Fullscreen / borderless  -> GPU (ddagrab, DXGI Desktop Duplication)
    * Windowed (has title bar) -> CPU (gdigrab, GDI BitBlt)
  Both paths deliver constant frame intervals — no more bursty / dropped
  frames in the recorded clip.
- WGC backend is bypassed by default. Windows.Graphics.Capture has a
  bursty delivery cadence under FiveM's flip-discard swap chain (long
  stretches at 0 fps interleaved with 30+ fps bursts), which produced
  jittery cinematics regardless of how cleanly the handler was written.
  The code is still in the binary in case it's revisited later, but the
  config keys (`capture_method`, `use_ddagrab`) are ignored.
- The Capture (GPU / CPU) picker in the FiveM editor's Export panel is
  gone. The recorder decides for you based on window mode; nothing to
  misconfigure.


What's new in v0.2.1
--------------------
- Throttle WGC frame delivery to the target capture framerate. Before,
  WGC fired our handler at the game's full present rate (often 100+ fps)
  and each fire ran a parallel memcpy across every CPU core to strip
  pixel padding — wasted work that fought the game for resources. With
  this fix, capture work is bounded to ~60 Hz regardless of game fps,
  so in-game framerate during recording stays much closer to normal.
- Suppress the ffmpeg console window. Spawned ffmpeg processes now run
  silently with CREATE_NO_WINDOW; no more black popup during capture,
  remux, motion-blur post-process, or boot-time encoder probes.


What's new in v0.2.0
--------------------
- New default capture backend: Windows.Graphics.Capture (WGC). Window-
  targeted GPU capture — same mode OBS uses for "Window Capture". ~5%
  CPU instead of gdigrab's ~50%, and only the FiveM window is recorded
  (your taskbar, second monitor, Discord overlay won't show up).
- Works with windowed, borderless, and fullscreen FiveM. Title bar is
  trimmed automatically when you're in windowed mode.
- 60 Hz wallclock sampler so output speed matches reality even when
  the game runs above target framerate (the v0.1.0 ddagrab path could
  speed up the output by 20-30% on fast machines).
- Pre-export staging: the editor now hides the UI and snaps the scene
  to the start frame BEFORE the recorder begins, so the captured video
  doesn't show the UI fading or vehicles flying into position.
- Fixed: libx264 CPU-encode probe was failing on every machine due to
  an odd-sized probe input. Affected anyone whose hardware encoders
  all rejected the probe (eg old NVIDIA driver + no AMD/Intel chips).
- Better diagnostics: panics from any thread now end up in the log
  file instead of being eaten by Windows.

Capture-method picker (in the FiveM editor's Export panel) is now two
options instead of three:
  - GPU (recommended)   — WGC
  - CPU (compatibility) — gdigrab, the universal fallback

The old ddagrab path is still in the recorder if you really need it
(set "capture_method": "ddagrab" in config.json) but it's hidden from
the UI because WGC is strictly better for FiveM.


Quick start (after you have done the Unblock above)
---------------------------------------------------
1. Double-click coreRecorder.exe.
   First boot: a loading screen appears and the recorder auto-downloads
   ffmpeg.exe (~78 MB) next to itself. The progress bar shows the
   download in real time. Subsequent boots are instant.

2. Leave the status panel open while you record. The editor's Export
   button talks to it over localhost — no manual interaction needed.

3. Finished clips land in:
     %USERPROFILE%\Videos\Core Cinematics\

If first boot fails (no internet, firewall, etc.) the panel shows
"Setup failed" + a Retry button. You can also drop your own ffmpeg.exe
next to coreRecorder.exe to skip the auto-download entirely.


Still does not run? (rare, after Unblock is done)
-------------------------------------------------
Windows Defender may have quarantined it silently. Check:

   Settings -> Privacy & security -> Windows Security
       -> Virus & threat protection -> Protection history

If coreRecorder.exe is listed there, click it and choose "Allow on
device". The exe is unsigned, so heuristics sometimes flag it; this
restores it permanently.

If Smart App Control is set to "On" (Windows 11), it will block any
unsigned exe with no UI. Settings -> Privacy & security -> Windows
Security -> App & browser control -> Smart App Control. Set it to
"Evaluation" or "Off". Note: this is one-way on Windows 11 — once
turned off, you cannot turn it back on without reinstalling Windows.


First-run popup warnings (the normal ones)
------------------------------------------
After Unblock, Windows may still show:
- "Windows protected your PC" (blue popup) -> click "More info" ->
  "Run anyway".
- Browser download warning ("isn't commonly downloaded") -> Keep.

Both are normal for unsigned exes from a small dev. They're separate
from the silent-block issue and can be clicked through.


Verify the download
-------------------
SHA-256 of coreRecorder.exe is in SHA256SUMS.txt next to this file.
Verify with PowerShell:
   Get-FileHash coreRecorder.exe -Algorithm SHA256


Logs
----
Daily-rotated under <recorder folder>\logs\recorder.log.YYYY-MM-DD.
Useful when reporting issues — paste the last few lines.
