﻿Core Recorder v0.1.0
====================


+--------------------------------------------------------------+
|                                                              |
|   ===> READ THIS FIRST OR THE APP WILL NOT RUN <===          |
|                                                              |
|   1. Extract the zip somewhere permanent (Documents,         |
|      Desktop, etc). Do NOT run from inside the zip.          |
|                                                              |
|   2. RIGHT-CLICK coreRecorder.exe -> Properties.             |
|                                                              |
|   3. At the BOTTOM of the General tab there is a checkbox    |
|      that says "Unblock" (next to a security warning).       |
|                                                              |
|   4. TICK "Unblock" -> click Apply -> click OK.              |
|                                                              |
|   5. NOW double-click coreRecorder.exe.                      |
|                                                              |
|   Without step 2-4, Windows may silently kill the exe with   |
|   no popup, no UAC prompt, no error. Nothing happens — you   |
|   double-click and Windows just blocks it in the background. |
|                                                              |
+--------------------------------------------------------------+


What is this?
-------------
Companion app for the Core Cinematics FiveM resource. Captures the GTA
window via ffmpeg and produces an .mp4 (with optional motion blur).
The editor talks to it on http://127.0.0.1:7861 — you do not open it
manually beyond the first launch.


Quick start (after you have done the Unblock above)
---------------------------------------------------
1. Double-click coreRecorder.exe.
   First boot: a loading screen appears and the recorder auto-downloads
   ffmpeg.exe (~78 MB) next to itself. The progress bar shows the
   download in real time. Subsequent boots are instant.

2. Leave the status panel open while you record. The editor's Export
   button talks to it over localhost — no manual interaction needed.

3. Finished clips land in:
     %USERPROFILE%\Videos\Core Cinematics\

If first boot fails (no internet, firewall, etc.) the panel shows
"Setup failed" + a Retry button. You can also drop your own ffmpeg.exe
next to coreRecorder.exe to skip the auto-download entirely.


Still does not run? (rare, after Unblock is done)
-------------------------------------------------
Windows Defender may have quarantined it silently. Check:

   Settings -> Privacy & security -> Windows Security
       -> Virus & threat protection -> Protection history

If coreRecorder.exe is listed there, click it and choose "Allow on
device". The exe is unsigned, so heuristics sometimes flag it; this
restores it permanently.

If Smart App Control is set to "On" (Windows 11), it will block any
unsigned exe with no UI. Settings -> Privacy & security -> Windows
Security -> App & browser control -> Smart App Control. Set it to
"Evaluation" or "Off". Note: this is one-way on Windows 11 — once
turned off, you cannot turn it back on without reinstalling Windows.


First-run popup warnings (the normal ones)
------------------------------------------
After Unblock, Windows may still show:
- "Windows protected your PC" (blue popup) -> click "More info" ->
  "Run anyway".
- Browser download warning ("isn't commonly downloaded") -> Keep.

Both are normal for unsigned exes from a small dev. They're separate
from the silent-block issue and can be clicked through.


Verify the download
-------------------
SHA-256 of coreRecorder.exe is in SHA256SUMS.txt next to this file.
Verify with PowerShell:
   Get-FileHash coreRecorder.exe -Algorithm SHA256


Logs
----
Daily-rotated under <recorder folder>\logs\recorder.log.YYYY-MM-DD.
Useful when reporting issues — paste the last few lines.
